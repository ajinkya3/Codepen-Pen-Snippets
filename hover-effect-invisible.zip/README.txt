A Pen created at CodePen.io. You can find this one at http://codepen.io/ajinkyadalvi/pen/dpVORw.

 Hover over to make the text visible! Hover Effects