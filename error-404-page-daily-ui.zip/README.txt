A Pen created at CodePen.io. You can find this one at http://codepen.io/ajinkyadalvi/pen/ozqJvm.

 Error 404 page with creative gif.